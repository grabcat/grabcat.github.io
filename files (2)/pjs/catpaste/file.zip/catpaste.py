#!/usr/bin/env python3
"""
CatPaste - lightweight local clipboard share tool
Run:  python catpaste.py
Then open http://localhost:5000 in your browser.
Paste text, get a short link. No account, no tracking.
"""

import http.server
import urllib.parse
import json
import random
import string
import os

PORT = 5000
store = {}

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CatPaste</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Verdana,sans-serif;background:#1f1f1f;color:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}}
.box{{background:#2b2b2b;border:2px solid #3d3d3d;border-radius:10px;padding:35px;width:100%;max-width:600px}}
h1{{color:#ffd54a;margin-bottom:8px;font-size:28px}}
p{{color:#c7c7c7;font-size:14px;margin-bottom:20px}}
textarea{{width:100%;height:160px;background:#1a1a1a;border:1px solid #555;border-radius:6px;color:#f5f5f5;padding:12px;font-family:Consolas,monospace;font-size:14px;resize:vertical;margin-bottom:14px}}
button{{width:100%;padding:11px;background:#ffd54a;color:#111;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:15px}}
button:hover{{background:#e6be35}}
.result{{margin-top:16px;background:#1a1a1a;border:1px solid #555;border-radius:6px;padding:12px;font-family:Consolas,monospace;font-size:14px;word-break:break-all;display:none}}
.result a{{color:#ffd54a}}
</style>
</head>
<body>
<div class="box">
  <h1>CatPaste</h1>
  <p>Paste your text below and grab a short link to share it locally.</p>
  <textarea id="txt" placeholder="Paste something here..."></textarea>
  <button onclick="send()">Generate Link</button>
  <div class="result" id="res"></div>
</div>
<script>
async function send(){{
  const txt = document.getElementById('txt').value.trim();
  if(!txt)return;
  const r = await fetch('/save',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{text:txt}})}});
  const d = await r.json();
  const box = document.getElementById('res');
  box.style.display='block';
  box.innerHTML='Link: <a href="/p/'+d.id+'" target="_blank">http://localhost:{port}/p/'+d.id+'</a>';
}}
</script>
</body>
</html>""".format(port=PORT)

VIEW = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CatPaste — {id}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Verdana,sans-serif;background:#1f1f1f;color:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}}
.box{{background:#2b2b2b;border:2px solid #3d3d3d;border-radius:10px;padding:35px;width:100%;max-width:640px}}
h2{{color:#ffd54a;margin-bottom:16px}}
pre{{background:#1a1a1a;border:1px solid #555;border-radius:6px;padding:14px;font-family:Consolas,monospace;font-size:14px;white-space:pre-wrap;word-break:break-all;line-height:1.6}}
.back{{display:block;margin-top:16px;color:#ffd54a;font-size:14px;text-decoration:none}}
.back:hover{{text-decoration:underline}}
</style>
</head>
<body>
<div class="box">
  <h2>Paste #{id}</h2>
  <pre>{text}</pre>
  <a class="back" href="/">← New paste</a>
</div>
</body>
</html>"""


def make_id(n=6):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # quiet

    def do_GET(self):
        if self.path == '/':
            self.reply(200, 'text/html', HTML.encode())
        elif self.path.startswith('/p/'):
            pid = self.path[3:]
            if pid in store:
                page = VIEW.format(id=pid, text=store[pid].replace('<','&lt;').replace('>','&gt;'))
                self.reply(200, 'text/html', page.encode())
            else:
                self.reply(404, 'text/plain', b'Paste not found.')
        else:
            self.reply(404, 'text/plain', b'Not found.')

    def do_POST(self):
        if self.path == '/save':
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length)
            data = json.loads(body)
            pid = make_id()
            store[pid] = data.get('text', '')
            self.reply(200, 'application/json', json.dumps({'id': pid}).encode())
        else:
            self.reply(404, 'text/plain', b'Not found.')

    def reply(self, code, ctype, body):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)


if __name__ == '__main__':
    print(f"CatPaste running at http://localhost:{PORT}")
    print("Press Ctrl+C to stop.")
    with http.server.HTTPServer(('', PORT), Handler) as srv:
        srv.serve_forever()
