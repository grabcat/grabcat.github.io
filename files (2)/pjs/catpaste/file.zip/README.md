# CatPaste

A lightweight local clipboard-share tool. No account, no internet, no tracking.

## Usage

Requires Python 3.6+. No extra packages needed.

```
python catpaste.py
```

Then open http://localhost:5000 in your browser.

Paste any text, hit **Generate Link**, and share the link with anyone on the same network.
Pastes live in memory — they're gone when you stop the server.

## Made by GrabCat
